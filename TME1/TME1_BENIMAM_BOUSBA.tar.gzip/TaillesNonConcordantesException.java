import java.lang.Exception;

public class TaillesNonConcordantesException extends Exception{

    public TaillesNonConcordantesException(){
        super("Tailles Non Concordantes");
    }
}